
package com.quizbuilder.auth.controller;

import com.quizbuilder.auth.service.AuthService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/signup")
    public ResponseEntity<String> signup(@RequestBody AuthRequest request) {
        String result = authService.register(request.getEmail(), request.getPassword());
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AuthRequest request) {
        boolean valid = authService.login(request.getEmail(), request.getPassword());
        return valid ? ResponseEntity.ok("Login successful") :
                       ResponseEntity.status(401).body("Invalid email or password");
    }

    @Data
    static class AuthRequest {
        private String email;
        private String password;
    }
}
